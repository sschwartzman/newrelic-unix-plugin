var fs = require('fs');
var inputJSON = JSON.parse(fs.readFileSync('./UnixMetrics.json', 'utf8'));

inputJSON.forEach(function(os) {
    var outfile = fs.createWriteStream('./plugin.json.new.' + os.os);
    var outJSON = {};
    outJSON['global'] = {
        'os' : os.os,
        'debug': false,
        'hostname': 'auto',
		"disksCommand": "",
  		"disksRegex": "",
  		"interfacesCommand": "",
  		"interfacesRegex": "",
  		'pageSize': os.pageSize
    };
    
    if("pageSizeCommand" in os) {
        outJSON.global.pageSizeCommand = os.pageSizeCommand.join(" ");
    }
    
    outJSON['agents'] = [];    

    var metrics = {};
    for(var metric in os.allMetrics) {
        var splitname = metric.split("/");
        if(!(splitname[0] in metrics)) {
            metrics[splitname[0]] = {};
        }
        var metricout = os.allMetrics[metric];
        metricout.type = metricout.this_type;
        delete metricout.this_type;
        metrics[splitname[0]][splitname[1]] = metricout;
    }

    for(var comm in os.allCommands) {
        var oldcomm = os.allCommands[comm];
        var newcomm = {
        	"name" : comm,
        	"command" : oldcomm.commands[0].join(" "),
            "checkAllRegex" : oldcomm.checkAllRegex,
            "lineLimit" : oldcomm.lineLimit,
            "type" : oldcomm.type,
            "mappings": oldcomm.lineMappings,
            "metrics" : metrics[comm]   
        };

        outJSON.agents.push(newcomm);
    } 

    outfile.write(JSON.stringify(outJSON, null, 2));
    outfile.close;
});